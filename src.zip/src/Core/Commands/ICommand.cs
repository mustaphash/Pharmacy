﻿namespace Core.Commands
{
    public interface ICommand
    {
    }
}
