﻿namespace Core.Queries
{
    public interface IQuery<TResult>
    {
    }
}
