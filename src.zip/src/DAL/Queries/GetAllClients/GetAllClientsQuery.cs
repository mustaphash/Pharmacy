﻿using Core.Entities;
using Core.Queries;

namespace DAL.Queries.GetAllClients
{
    public class GetAllClientsQuery : IQuery<IList<Client>>
    {
    }
}
