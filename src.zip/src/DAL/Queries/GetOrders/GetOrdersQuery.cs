﻿using Core.Entities;
using Core.Queries;

namespace DAL.Queries.GetOrders
{
    public class GetOrdersQuery : IQuery<IList<Order>>
    {
    }
}
