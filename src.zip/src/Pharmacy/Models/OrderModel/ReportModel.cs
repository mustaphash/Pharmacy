﻿namespace Pharmacy.Models.OrderModel
{
    public class ReportModel
    {
        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }
    }
}
